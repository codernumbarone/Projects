


public enum DirectionState {
	North , East , West , South
}



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class test {
	public static InstructionState[] p1 = new InstructionState[] {InstructionState.Forward, InstructionState.Left, InstructionState.Right, InstructionState.Right, InstructionState.Left,InstructionState.Right, InstructionState.Left, InstructionState.Right};
	public static InstructionState[] p2 = new InstructionState[] {InstructionState.Forward, InstructionState.Left, InstructionState.Left, InstructionState.Left,InstructionState.Forward };
	public static InstructionState[] p3 = new InstructionState[] {InstructionState.Forward, InstructionState.Right, InstructionState.Right, InstructionState.Right, InstructionState.Left};
	public static InstructionState[] p4 = new InstructionState[] {InstructionState.Forward, InstructionState.Right, InstructionState.Forward, InstructionState.Left, InstructionState.Forward,InstructionState.Forward, InstructionState.Forward, InstructionState.Left};
	public static InstructionState[] p5 = new InstructionState[] {InstructionState.Forward, InstructionState.Right, InstructionState.Right, InstructionState.Right,InstructionState.Forward };
	public static InstructionState[] p6 = new InstructionState[] {InstructionState.Forward, InstructionState.Left, InstructionState.Left, InstructionState.Left, InstructionState.Right};

	
	
	public static Object [][] map = new Object [4][4];
	public static Car car1 = new Car("Car1" , 0 , 0);
	public static Car car2  =new Car("Car2" , 0 , 3);
	
	public static void main(String[] args) throws FileNotFoundException {
		List<InstructionState> one = new ArrayList<InstructionState> (10);
		List<InstructionState> two = new ArrayList<InstructionState> (10);
		List<InstructionState> three = new ArrayList<InstructionState> (10);
		List<InstructionState> four = new ArrayList<InstructionState> (10);
		List<InstructionState> five = new ArrayList<InstructionState> (10);
		List<InstructionState> six = new ArrayList<InstructionState> (10);
		List<InstructionState> test = new ArrayList<InstructionState> (10);


		intializeMap();
		
//		System.out.println("x = " + car1.x + " y = " +car1.y);

		
		for(int i=0;i<p1.length;i++) {
			if(p1[i]==InstructionState.Forward) {
				car1.MoveForward1();
				one.add(InstructionState.Forward);

//				System.out.println(p1[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p1[i]==InstructionState.Left) {
				car1.MoveLeft1();
				one.add(InstructionState.Left);
//				System.out.println(p1[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p1[i]==InstructionState.Right) {
				car1.MoveRight1();
				one.add(InstructionState.Right);
//				System.out.println(p1[i]);
//				System.out.println("x = " + car1.x + "  = " +car1.y);

			}
		}
		for(int i=0;i<p2.length;i++) {
			if(p2[i]==InstructionState.Forward) {
				car1.MoveForward1();
				two.add(InstructionState.Forward);

//				System.out.println(p2[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p2[i]==InstructionState.Left) {
				car1.MoveLeft1();
				two.add(InstructionState.Left);
//				System.out.println(p2[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p2[i]==InstructionState.Right) {
				car1.MoveRight1();
				two.add(InstructionState.Right);
//				System.out.println(p2[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}
		}
		for(int i=0;i<p3.length;i++) {
			if(p3[i]==InstructionState.Forward) {
				car1.MoveForward1();
				three.add(InstructionState.Forward);

//				System.out.println(p3[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p3[i]==InstructionState.Left) {
				car1.MoveLeft1();
				three.add(InstructionState.Left);
//				System.out.println(p3[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}else if(p3[i]==InstructionState.Right) {
				car1.MoveRight1();
				three.add(InstructionState.Right);
//				System.out.println(p3[i]);
//				System.out.println("x = " + car1.x + " y = " +car1.y);

			}
		}
		for(int i=0;i<p4.length;i++) {
			if(p4[i]==InstructionState.Forward) {
				car2.MoveForward1();
				four.add(InstructionState.Forward);

//				System.out.println(p4[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p4[i]==InstructionState.Left) {
				car2.MoveLeft1();
				four.add(InstructionState.Left);
//				System.out.println(p4[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p4[i]==InstructionState.Right) {
				car2.MoveRight1();
				four.add(InstructionState.Right);
//				System.out.println(p4[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}
		}
		for(int i=0;i<p5.length;i++) {
			if(p5[i]==InstructionState.Forward) {
				car2.MoveForward1();
				five.add(InstructionState.Forward);

//				System.out.println(p5[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p5[i]==InstructionState.Left) {
				car2.MoveLeft1();
				five.add(InstructionState.Left);
//				System.out.println(p5[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p5[i]==InstructionState.Right) {
				car2.MoveRight1();
				five.add(InstructionState.Right);
//				System.out.println(p5[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}
		}
		for(int i=0;i<p6.length;i++) {
			if(p6[i]==InstructionState.Forward) {
				car2.MoveForward1();
				six.add(InstructionState.Forward);
//				System.out.println(p6[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p6[i]==InstructionState.Left) {
				car2.MoveLeft1();
				six.add(InstructionState.Left);
//				System.out.println(p6[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}else if(p6[i]==InstructionState.Right) {
				car2.MoveRight1();
				six.add(InstructionState.Right);
//				System.out.println(p6[i]);
//				System.out.println("x = " + car2.x + " y = " +car2.y);

			}
		}
		FileInputStream serviceAccount = new FileInputStream("/Users/zayed/Downloads/iotfirebaseproject-de118-firebase-adminsdk-2ng6f-6eac008d46.json");



		FirebaseOptions options = new FirebaseOptions.Builder()
		    .setServiceAccount(serviceAccount)
		    .setDatabaseUrl("https://iotfirebaseproject-de118.firebaseio.com//")
		    .build();

		FirebaseApp.initializeApp(options);
		
		final FirebaseDatabase database1 = FirebaseDatabase.getInstance();
		DatabaseReference ref1 = database1.getReference("C1I1");
		ref1.setValue(one);
		DatabaseReference ref2 = database1.getReference("C1I2");
		ref2.setValue(two);
		DatabaseReference ref3 = database1.getReference("C1I3");
		ref3.setValue(three);
		DatabaseReference ref4 = database1.getReference("C2I1");
		ref4.setValue(four);
		DatabaseReference ref5 = database1.getReference("C2I2");
		ref5.setValue(five);
		DatabaseReference ref6 = database1.getReference("C2I3");
		ref6.setValue(six);
		DatabaseReference c1 = database1.getReference("Car1 Location");
		c1.setValue("0,0");
		DatabaseReference c2 = database1.getReference("Car2 Location");
		c2.setValue("0,3");
		DatabaseReference coin1 = database1.getReference("CoinOne Location");
		coin1.setValue("1,1");
		DatabaseReference coin2 = database1.getReference("CoinTwo Location");
		coin2.setValue("1,2");
		DatabaseReference coin3 = database1.getReference("CoinThree Location");
		coin3.setValue("1,3");
		DatabaseReference coin4 = database1.getReference("CoinFour Location");
		coin4.setValue("2,1");
		DatabaseReference coin5 = database1.getReference("CoinFive Location");
		coin5.setValue("2,2");
		DatabaseReference coin6 = database1.getReference("CoinSix Location");
		coin6.setValue("2,3");
		DatabaseReference Bin1 = database1.getReference("Bin1 Location");
		Bin1.setValue("3,0");
		DatabaseReference Bin2 = database1.getReference("Bin2 Location");
		Bin2.setValue("3,3");
//		print();
		
		
		for(int i=0;i<printPath(0,0,2,1).size();i++) {
			System.out.println(printPath(0,0,2,1).get(i).toString());	
}
}
	public static void intializeMap()
	{
		map[0][0] = car1;
		map[0][3] = car2;
		
		map[3][0] = "Bin1";
		map[3][3] = "Bin2";
		
		map[2][2] = "Coin1";
		map[1][1] = "Coin2";
		map[1][2] = "Coin3";
		map[1][3] = "Coin4";
		map[2][1] = "Coin5";
		map[2][3] = "Coin6";

		
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				if(map[i][j] == null)
				{
					map[i][j] = "Idle";
				}
			}
		}
	}
	
	public static ArrayList<InstructionState> printPath(int xs, int ys, int xd, int yd) {
		int c1=0;
		int c2=0;
		List<InstructionState> path = new ArrayList<InstructionState> (10);
		if(xs==xd && ys ==yd) {
			return null;
		}
			if(yd>ys) {
				while(ys<yd) {
					path.add(InstructionState.Forward);
					ys++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						path.add(InstructionState.Left);
					c1++;}else {
						path.add(InstructionState.Forward);

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						path.add(InstructionState.Right);
						c2++;}else {
							path.add(InstructionState.Forward);
				}
					xd++;
			}
			}
		return (ArrayList<InstructionState>) path;
	}
	public static void print() 
	{
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				System.out.print(map[i][j].toString() + "  ");
			}
		System.out.println(" ");
		
		}
	}
	
}
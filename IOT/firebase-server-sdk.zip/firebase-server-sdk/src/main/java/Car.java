

public class Car {

	public String name;
	public int x;
	public int y;
	public DirectionState direction;
	public InstructionState instructions;

	public Car(String name , int x, int y) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.direction = DirectionState.South;
	}
	
	public void moveTo(int x , int y)
	{
		
		if(this.direction == DirectionState.East && instructions == InstructionState.Forward)
		{
		x++;
		}
		if(this.direction == DirectionState.East && instructions == InstructionState.Right)
		{
		y++;
		}
		if(this.direction == DirectionState.East && instructions == InstructionState.Left)
		{
		y--;
		}
		if(this.direction == DirectionState.West && instructions == InstructionState.Forward)
		{
		x--;	
		}
		if(this.direction == DirectionState.West && instructions == InstructionState.Right)
		{
		y--;	
		}
		if(this.direction == DirectionState.West && instructions == InstructionState.Left)
		{
		y++;	
		}
		if(this.direction == DirectionState.South && instructions == InstructionState.Forward)
		{
		y++;	
		}
		if(this.direction == DirectionState.South && instructions == InstructionState.Right)
		{
		x--;
		}
		if(this.direction == DirectionState.South && instructions == InstructionState.Left)
		{
		x++;	
		}
		if(this.direction == DirectionState.North && instructions == InstructionState.Forward)
		{
		y--;	
		}
		if(this.direction == DirectionState.North && instructions == InstructionState.Right)
		{
		x++;	
		}
		if(this.direction == DirectionState.North && instructions == InstructionState.Left)
		{
		x--;	
		}
		this.x = x;
		this.y = y;
	}
	
	public void MoveForward(DirectionState d) {
		if(d == DirectionState.East)
		{
		x++;
		}
		if(d == DirectionState.West)
		{
		x--;
		}
		if(d == DirectionState.South)
		{
		y++;
		}
		if(d == DirectionState.North)
		{
		y--;
		}

	}
	public void MoveLeft(DirectionState d) {
		if(d == DirectionState.East)
		{
		y--;
		}
		if(d == DirectionState.West)
		{
		y++;
		}
		if(d == DirectionState.South)
		{
		x++;
		}
		if(d == DirectionState.North)
		{
		x--;
		}

	}
	public void MoveRight(DirectionState d) {
		if(d == DirectionState.East)
		{
		y++;
		}
		if(d == DirectionState.West)
		{
		y--;
		}
		if(d == DirectionState.South)
		{
		x--;
		}
		if(d == DirectionState.North)
		{
		x++;
		}

	}
	
	public void MoveForward1() {
		y++;

	}
	public void MoveLeft1() {

		x++;

	}
	public void MoveRight1() {
	
		x--;
	
	}
	
	   private static boolean isOutOfMap(Object[][] map, int x, int y) {
	       if (x < 0 || y < 0) {
	           return true;
	       }
	       return map.length <= y || map[0].length <= x;
	   }

	public String toString()
	{
		return this.name;
	}
}

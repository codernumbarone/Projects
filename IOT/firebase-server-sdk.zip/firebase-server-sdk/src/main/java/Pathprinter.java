import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class Pathprinter {
	public static void main(String[] args)  
	{
		String a = printPath(3,3,2,1);
		System.out.println(a);
//		for(int i=0;i<printPath1(0,0,2,1).size();i++) {
//			System.out.println(printPath1(0,0,2,1).get(i).toString());	
//}
		}
	public static String printPath(int xs, int ys, int xd, int yd) {
		int c1=0;
		int c2=0;
		String x = " ";
		if(xs==xd && ys ==yd) {
			return null;
		}
		if(xs==0&&ys==3 || xs==3&&ys==3) {
			if(yd>ys) {
				while(ys<yd) {
					x=x+"Forward ";
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					x=x+"Forward ";
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						x=x+"Right ";
					c1++;}else {
						x=x+"Forward ";

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						x=x+"Left ";
						c2++;}else {
							x=x+"Forward ";
				}
					xd++;
			}
			}
		}else {
			if(yd>ys) {
				while(ys<yd) {
					x=x+"Forward ";
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					x=x+"Forward ";
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						x=x+"Left ";
					c1++;}else {
						x=x+"Forward ";

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						x=x+"Right ";
						c2++;}else {
							x=x+"Forward ";
				}
					xd++;
			}
			}
		}
		return x;
	}
	public static ArrayList<InstructionState> printPath1(int xs, int ys, int xd, int yd) {
		int c1=0;
		int c2=0;
		List<InstructionState> path = new ArrayList<InstructionState> ();
		if(xs==xd && ys ==yd) {
			return null;
		}
		if(xs==0&&ys==3 || xs==3&&ys==3) {
			if(yd>ys) {
				while(ys<yd) {
					path.add(InstructionState.Forward);
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					path.add(InstructionState.Forward);
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						path.add(InstructionState.Right);
					c1++;}else {
						path.add(InstructionState.Forward);

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						path.add(InstructionState.Left);
						c2++;}else {
							path.add(InstructionState.Forward);
				}
					xd++;
			}
			}
		}else {
			if(yd>ys) {
				while(ys<yd) {
					path.add(InstructionState.Forward);
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					path.add(InstructionState.Forward);
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						path.add(InstructionState.Left);
					c1++;}else {
						path.add(InstructionState.Forward);

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						path.add(InstructionState.Right);
						c2++;}else {
							path.add(InstructionState.Forward);
				}
					xd++;
			}
			}
		}
		return (ArrayList<InstructionState>) path;
	}

}

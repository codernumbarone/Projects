

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class iot {

	
	
	public static Object [][] map = new Object [4][4];
	public static Car car1 = new Car("Car1" , 0 , 0);
	public static Car car2  =new Car("Car2" , 0 , 3);
	
	public static void main(String[] args) throws FileNotFoundException {
		List<InstructionState> one = new ArrayList<InstructionState> ();
		List<InstructionState> two = new ArrayList<InstructionState> ();
		List<InstructionState> three = new ArrayList<InstructionState> ();
		List<InstructionState> four = new ArrayList<InstructionState> ();
		List<InstructionState> five = new ArrayList<InstructionState> ();
		List<InstructionState> six = new ArrayList<InstructionState> ();
		List<InstructionState> seven = new ArrayList<InstructionState> ();
		List<InstructionState> eight = new ArrayList<InstructionState> ();
		List<InstructionState> nine = new ArrayList<InstructionState> ();
		List<InstructionState> ten = new ArrayList<InstructionState> ();
		List<InstructionState> eleven = new ArrayList<InstructionState> ();
		List<InstructionState> twelve = new ArrayList<InstructionState> ();

one=printPath1(0, 0, 1, 1);
two=printPath1(1,1,0,3);
three=printPath1(0, 3, 1, 2);
four=printPath1(1,2,0,3);
five=printPath1(0, 3, 1, 3);
six=printPath1(1,3,0,3);

seven=printPath1(3,0,2,1);
eight=printPath1(2, 1, 3, 3);
nine=printPath1(3,3,2,2);
ten=printPath1(2,2,3,3);
eleven=printPath1(3, 3, 3, 1);
twelve=printPath1(3,1,3,3);

		
//		System.out.println("x = " + car1.x + " y = " +car1.y);


		FileInputStream serviceAccount = new FileInputStream("/Users/zayed/Downloads/iotfirebaseproject-de118-firebase-adminsdk-2ng6f-6eac008d46.json");



		FirebaseOptions options = new FirebaseOptions.Builder()
		    .setServiceAccount(serviceAccount)
		    .setDatabaseUrl("https://iotfirebaseproject-de118.firebaseio.com//")
		    .build();

		FirebaseApp.initializeApp(options);
		
		final FirebaseDatabase database1 = FirebaseDatabase.getInstance();
		DatabaseReference ref1 = database1.getReference("C1I1");
		ref1.setValue(one);
		DatabaseReference ref2 = database1.getReference("C1I2");
		ref2.setValue(two);
		DatabaseReference ref3 = database1.getReference("C1I3");
		ref3.setValue(three);
		DatabaseReference ref4 = database1.getReference("C1I4");
		ref4.setValue(four);
		DatabaseReference ref5 = database1.getReference("C1I5");
		ref5.setValue(five);
		DatabaseReference ref6 = database1.getReference("C1I6");
		ref6.setValue(six);
		DatabaseReference ref7 = database1.getReference("C2I1");
		ref7.setValue(seven);
		DatabaseReference ref8 = database1.getReference("C2I2");
		ref8.setValue(eight);
		DatabaseReference ref9 = database1.getReference("C2I3");
		ref9.setValue(nine);
		DatabaseReference ref10 = database1.getReference("C2I4");
		ref10.setValue(ten);
		DatabaseReference ref11 = database1.getReference("C2I5");
		ref11.setValue(eleven);
		DatabaseReference ref12 = database1.getReference("C2I6");
		ref12.setValue(twelve);
		DatabaseReference s1 = database1.getReference("Size1");
		s1.setValue(one.size());
		DatabaseReference s2 = database1.getReference("Size2");
		s2.setValue(two.size());
		DatabaseReference s3 = database1.getReference("Size3");
		s3.setValue(three.size());
		DatabaseReference s4 = database1.getReference("Size4");
		s4.setValue(four.size());
		DatabaseReference s5 = database1.getReference("Size5");
		s5.setValue(five.size());
		DatabaseReference s6 = database1.getReference("Size6");
		s6.setValue(six.size());
		DatabaseReference s7 = database1.getReference("Size7");
		s7.setValue(seven.size());
		DatabaseReference s8 = database1.getReference("Size8");
		s8.setValue(eight.size());
		DatabaseReference s9 = database1.getReference("Size9");
		s9.setValue(nine.size());
		DatabaseReference s10 = database1.getReference("Size10");
		s10.setValue(ten.size());
		DatabaseReference s11 = database1.getReference("Size11");
		s11.setValue(eleven.size());
		DatabaseReference s12 = database1.getReference("Size12");
		s12.setValue(twelve.size());
		
		DatabaseReference c1 = database1.getReference("Car1 Location");
		c1.setValue("0,0");
		DatabaseReference c2 = database1.getReference("Car2 Location");
		c2.setValue("0,3");
//		DatabaseReference coin1 = database1.getReference("CoinOne Location");
//		coin1.setValue("1,1");
//		DatabaseReference coin2 = database1.getReference("CoinTwo Location");
//		coin2.setValue("1,2");
//		DatabaseReference coin3 = database1.getReference("CoinThree Location");
//		coin3.setValue("1,3");
//		DatabaseReference coin4 = database1.getReference("CoinFour Location");
//		coin4.setValue("2,1");
//		DatabaseReference coin5 = database1.getReference("CoinFive Location");
//		coin5.setValue("2,2");
//		DatabaseReference coin6 = database1.getReference("CoinSix Location");
//		coin6.setValue("2,3");
		DatabaseReference Bin1 = database1.getReference("Bin1 Location");
		Bin1.setValue("3,0");
		DatabaseReference Bin2 = database1.getReference("Bin2 Location");
		Bin2.setValue("3,3");
//		print();
		
		
	

}
	public static void intializeMap()
	{
		map[0][0] = car1;
		map[0][3] = car2;
		
		map[3][0] = "Bin1";
		map[3][3] = "Bin2";
		
		map[2][2] = "Coin1";
		map[1][1] = "Coin2";
		map[1][2] = "Coin3";
		map[1][3] = "Coin4";
		map[2][1] = "Coin5";
		map[2][3] = "Coin6";

		
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				if(map[i][j] == null)
				{
					map[i][j] = "Idle";
				}
			}
		}
	}
	
	public static String printPath(int xs, int ys, int xd, int yd) {
		int c1=0;
		int c2=0;
		String x = " ";
		if(xs==xd && ys ==yd) {
			return null;
		}
		if(xs==0&&ys==3 || xs==3&&ys==3) {
			if(yd>ys) {
				while(ys<yd) {
					x=x+"Forward ";
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					x=x+"Forward ";
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						x=x+"Right ";
					c1++;}else {
						x=x+"Forward ";

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						x=x+"Left ";
						c2++;}else {
							x=x+"Forward ";
				}
					xd++;
			}
			}
		}else {
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						x=x+"Left ";
					c1++;}else {
						x=x+"Forward ";

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						x=x+"Right ";
						c2++;}else {
							x=x+"Forward ";
				}
					xd++;
			}
			}
				if(yd>ys) {
					while(ys<yd) {
						x=x+"Forward ";
						ys++;
					}
				}else if(ys>yd) {
					while(ys>yd) {
						x=x+"Forward ";
						yd++;
					}
				}
		}
		return x;
	}
	public static ArrayList<InstructionState> printPath1(int xs, int ys, int xd, int yd) {
		int c1=0;
		int c2=0;
		List<InstructionState> path = new ArrayList<InstructionState> ();
		if(xs==xd && ys ==yd) {
			return null;
		}
		if(xs==0&&ys==3 || xs==3&&ys==3) {
			if(yd>ys) {
				while(ys<yd) {
					path.add(InstructionState.Forward);
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					path.add(InstructionState.Forward);
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						path.add(InstructionState.Right);
					c1++;}else {
						path.add(InstructionState.Forward);

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						path.add(InstructionState.Left);
						c2++;}else {
							path.add(InstructionState.Forward);
				}
					xd++;
			}
			}
		}else {
			if(yd>ys) {
				while(ys<yd) {
					path.add(InstructionState.Forward);
					ys++;
				}
			}else if(ys>yd) {
				while(ys>yd) {
					path.add(InstructionState.Forward);
					yd++;
				}
			}
			 if(xd>xs) {
				while(xd>xs) {
					if(c1==0) {
						path.add(InstructionState.Left);
					c1++;}else {
						path.add(InstructionState.Forward);

					}
					xs++;
				}
			}else if(xs>xd) {
				while(xs>xd) {
					if(c2==0) {
						path.add(InstructionState.Right);
						c2++;}else {
							path.add(InstructionState.Forward);
				}
					xd++;
			}
			}
		}
		return (ArrayList<InstructionState>) path;
	}
	public static void print() 
	{
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				System.out.print(map[i][j].toString() + "  ");
			}
		System.out.println(" ");
		
		}
	}
	
}
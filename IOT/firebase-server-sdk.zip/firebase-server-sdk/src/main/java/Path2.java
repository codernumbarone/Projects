 import java.util.ArrayList;

   public class Path2
   {
    static ArrayList<String> paths = new ArrayList<String>(); 

    public static long getUnique(int m, int n, int i, int j, String pathlist)
    {

        pathlist += ("(" + i + ", " + (j) + ") => ");

        if(m == i && n == j)
        {       
            paths.add(pathlist); 
        }

        if( i > m || j > n)
        {
            return 0;               
        }

        return getUnique(m, n, i+1, j, pathlist)+getUnique(m, n, i, j+1, pathlist); 

    }

    public static void printPaths()
    {
        int count = 1;
        System.out.println("There are "+paths.size() + " unique paths: \n");

        for (int i = paths.size()-1; i>=0; i--)
        {

         System.out.println( "path " + count + ":   " + paths.get(i));
         count++;
        }

    }

    public static void main(String args[])
    {
        final int start_Point = 1;
        int grid_Height = 2; 
        int grid_Width = 2; 

        getUnique(grid_Height, grid_Width, start_Point, start_Point, "");
        printPaths(); 

    }

}
package com.example.iot;

public class Location {

    String Direction;
    String LocationId;

    public Location(){

    }
    public Location(String LocationId, String Direction){
        this.LocationId = LocationId;
        this.Direction= Direction;
    }

    public String getDirection() {
        return Direction;
    }

    public String getLocationId() {
        return LocationId;
    }
}

package com.example.iot;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button Path1;
    Button Path2;
    Button Path3;
    Button Path4;
    Button Path5;
    Button Path6;
    Button Path7;
    Button Path8;
    Button Path9;
    Button Path10;
    Button Path11;
    Button Path12;
    Button g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13,g14,g15,g16;
    Button Stop;
    TextView tt;

    String Location;
    DatabaseReference databaseLocation;
    DatabaseReference databaseLocation1;

    String id;
    int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Path1 = (Button) findViewById(R.id.c1i1);
        Path2 = (Button) findViewById(R.id.c1i2);
        Path3 = (Button) findViewById(R.id.c1i3);
        Path4 = (Button) findViewById(R.id.c1i4);
        Path5 = (Button) findViewById(R.id.c1i5);
        Path6 = (Button) findViewById(R.id.c1i6);

        Path7 = (Button) findViewById(R.id.c2i1);
        Path8 = (Button) findViewById(R.id.c2i2);
        Path9 = (Button) findViewById(R.id.c2i3);
        Path10 = (Button) findViewById(R.id.c2i4);
        Path11 = (Button) findViewById(R.id.c2i5);
        Path12 = (Button) findViewById(R.id.c2i6);
        Stop = (Button) findViewById(R.id.stop);

        g2 = (Button) findViewById(R.id.g2);
        g3 = (Button) findViewById(R.id.g3);
        g5 = (Button) findViewById(R.id.g5);
        g6 = (Button) findViewById(R.id.g6);
        g7 = (Button) findViewById(R.id.g7);
        g8 = (Button) findViewById(R.id.g8);
        g9 = (Button) findViewById(R.id.g9);
        g10 = (Button) findViewById(R.id.g10);
        g11 = (Button) findViewById(R.id.g11);
        g12 = (Button) findViewById(R.id.g12);
        g14 = (Button) findViewById(R.id.g14);
        g15 = (Button) findViewById(R.id.g15);

        g1 = (Button) findViewById(R.id.g1);
        g4 = (Button) findViewById(R.id.g4);
        g13 = (Button) findViewById(R.id.g13);
        g16 = (Button) findViewById(R.id.g16);
        tt = (TextView) findViewById(R.id.textView);
g13.setBackgroundResource(R.drawable.bin);
g16.setBackgroundResource(R.drawable.bin);
g1.setBackgroundResource(R.drawable.car);
g4.setBackgroundResource(R.drawable.car);
        counter = 0;

        databaseLocation = FirebaseDatabase.getInstance().getReference("Path");

        Path1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(1);
            }
        });
        Path2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(2);
            }
        });

        Path3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(3);

            }
        });

        Path4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(4);

            }
        });
        Path5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(5);

            }
        });
        Path6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(6);

            }
        });
        Path7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(7);
            }
        });
        Path8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(8);
            }
        });

        Path9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(9);

            }
        });

        Path10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(10);

            }
        });
        Path11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(11);

            }
        });
        Path12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(12);

            }
        });

        Stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseLocation.setValue(0);

            }
        });

            g2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6) {
                        g2.setBackgroundResource(R.drawable.coin);

                    counter++;}
                }
            });
            g3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g3.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g5.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g6.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g7.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6) {
                        g8.setBackgroundResource(R.drawable.coin);
                        counter++;
                    }
                }
            });
            g8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g8.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g9.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6) {
                        g10.setBackgroundResource(R.drawable.coin);
                        counter++;
                    }

                }
            });
            g11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g11.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g12.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g14.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });
            g15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(counter<6){
                    g15.setBackgroundResource(R.drawable.coin);
                    counter++;}

                }
            });

    }





}

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class server {

	private static ArrayList<AndroidThread> onlineUsers;
	private static BufferedReader inFromClient;
	private static DataOutputStream outToClient;

	public static void main(String[] args) throws IOException {

		ServerSocket welcomeSocket = new ServerSocket(7777);
		System.out.println("server running on port 7777");
		onlineUsers = new ArrayList<AndroidThread>();

		while (true) {
			boolean condition = true;
			Socket connectionSocket = welcomeSocket.accept();
			inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			System.out.println("new android connection,port :"+connectionSocket.getPort());

			while (condition) {

				String name = "";
				name = inFromClient.readLine();

				if (NameTaken(name)) {
					outToClient.writeBytes("sorry" + '\n');
				} else {
					outToClient.writeBytes("success," + name + '\n');
					AndroidThread x = new AndroidThread(name, connectionSocket);
					onlineUsers.add(x);
					sendList();
					x.start();
					condition = false;
				}
			}
		}
	}

	public static ArrayList<AndroidThread> getList() {
		return onlineUsers;
	}

	private static boolean NameTaken(String name) throws IOException {

		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(name)) {
				return true;
			}
		}
		return false;
	}

	private static void sendList() throws IOException {
		String x = "List of available online users:,";
		for (int i = 0; i < onlineUsers.size(); i++) {
			x += onlineUsers.get(i).name + ",";
		}
		for (int i = 0; i < onlineUsers.size(); i++) {
			onlineUsers.get(i).outToClient.writeBytes(x + '\n');
		}
	}
}

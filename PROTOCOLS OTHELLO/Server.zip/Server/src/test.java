
public class test {

	public static void main(String[] args) {

		String x = "game," + "zoziooioi," + "b,k,j,h";
		String opp = x.split(",")[1];
		int index = 3 + 1 + opp.length()+2;
		String maptosend = x.substring(index, x.length());
		System.out.println(maptosend);
	}
}

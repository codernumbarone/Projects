import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;

public class AndroidThread extends Thread {

	public String name;
	public Socket connectionSocket;
	public BufferedReader inFromClient;
	public DataOutputStream outToClient;
	public boolean isBusy;
	public boolean moves=true;
	
	public AndroidThread(String name, Socket connectioSocket) throws IOException {
		this.name = name;
		this.connectionSocket = connectioSocket;
		this.inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
		this.outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		this.isBusy = false;
	}

	public void run() {
		while (true) {
			try {
				String received = inFromClient.readLine();
				if (received != null) {
					
					if (received.startsWith("kfaya")) {
						System.out.println("No more moves");
						String other = received.split(",")[1];
						merci(other);					
					}
					
					if (received.startsWith("Game")) {
						String opp = received.split(",")[1];
						int index = 3 + 1 + opp.length() + 2;
						String maptosend = received.substring(index, received.length());
						forward(maptosend, opp);

					}
						if (received.startsWith("request to")) {
							String nameChallenged = received.split(",")[1];
							sendRequest(nameChallenged);
						}
							if (received.startsWith("Accept")) {
								this.isBusy = true;
								String nameChallenged = received.split(",")[1];
								String nameHack = received.split(",")[2];
								setHack(nameHack);
								setBusy(nameChallenged);
							}
								if (received.startsWith("out")) {
									System.out.println("A player has quit");
									String quiter = received.split(",")[1];
									String winner = received.split(",")[2];
									System.out.println("quiter is " + quiter + " Winner is " + winner);
									quited(quiter,winner);
								}
									if (received.startsWith("Winner")) {
										System.out.println("THERE IS A WINNER");
										String winner = received.split(",")[1];
										System.out.println("Winner is " + winner);
										SendToAll("Winner,"+ winner);
									}
										if (received.startsWith("Tie")) {
											System.out.println("Its a Tie");
											SendToAll("Tie,");
										}

												if (received.startsWith("Reject")) {
													String nameChallenged = received.split(",")[1];
													setReject(nameChallenged);
												}

				} else {
					System.out.println("Recieved Null");
					Logout(this.name);
					sendList();
					this.connectionSocket.close();
					this.inFromClient.close();
					this.outToClient.close();
					return;
				}
			} catch (IOException e) {
			}
		}
	}

	private void setHack(String nameHack) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(nameHack)) {
				onlineUsers.get(i).outToClient.writeBytes("close"+'\n');
			}
		}
	}

	private void sendList() throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();

		String x = "List of available online users:,";
		for (int i = 0; i < onlineUsers.size(); i++) {
			x += onlineUsers.get(i).name + ",";
		}
		for (int i = 0; i < onlineUsers.size(); i++) {
			onlineUsers.get(i).outToClient.writeBytes(x + '\n');
		}
	}

	private void Logout(String userTobeKicked) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(userTobeKicked)) {
				onlineUsers.remove(onlineUsers.get(i));
			}
		}
	}

	private void setBusy(String nameChallenged) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(nameChallenged)) {
				onlineUsers.get(i).isBusy = true;
				onlineUsers.get(i).outToClient.writeBytes("BATTLE," + this.name + '\n');
			}
		}
	}

	private void setReject(String nameChallenged) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(nameChallenged)) {
				onlineUsers.get(i).outToClient.writeBytes("Reject" + '\n');
			}
		}
	}
	private void quited(String quiter,String winner) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(winner)) {
				onlineUsers.get(i).outToClient.writeBytes("quit," + quiter+'\n');
			}
		}
	}

	private void forward(String map, String opp) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(opp)) {
				onlineUsers.get(i).outToClient.writeBytes(map + '\n');
			}
		}
	}
	
	private void merci(String opp) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(opp)) {
				onlineUsers.get(i).outToClient.writeBytes("no," + '\n');
			}
		}
	}
	
	public void SendToAll(String message) throws IOException{
		ArrayList<AndroidThread> onlineUsers = server.getList();
		for(int i =0;i<onlineUsers.size();i++){
			onlineUsers.get(i).outToClient.writeBytes(message+'\n');
		}

	}
	private void sendRequest(String nameChallenged) throws IOException {
		ArrayList<AndroidThread> onlineUsers = server.getList();

		for (int i = 0; i < onlineUsers.size(); i++) {
			if (onlineUsers.get(i).name.equals(nameChallenged)) {
				if (onlineUsers.get(i).isBusy == false) {
					onlineUsers.get(i).outToClient
					.writeBytes("challenge ," + this.name + " is challenging you" + "," + this.name + '\n');
				} else {
					this.outToClient.writeBytes("sorry," + nameChallenged + " is busy now" + '\n');
				}
			}
		}
	}
}
